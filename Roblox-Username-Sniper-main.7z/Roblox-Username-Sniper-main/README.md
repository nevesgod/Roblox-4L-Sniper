# Roblox Username Sniper

This Project Allows People To Snipe Specific Names Such As 4L UN and above.

## How to Use

### 1. Running the Username Sniper
Run the following command to generate usernames:
```sh
python UG.py
```
This will generate usernames and save them to `usernames.txt`.

### 2. Manually Creating `usernames.txt`
If you prefer, you can manually create `usernames.txt` and then run `main.py` to use an existing file.

## File Structure
- [`main.py`](./main.py) - Main Script To Snipe Names
- [`UG.py`](./UG.py) - Script to generate and save usernames.
- [`usernames.txt`](./usernames.txt) - Output file containing generated usernames.

## Requirements
- Python 3.x

## Notes
- The script generates a large number of usernames efficiently using optimized methods.
- Usernames are saved one per line in `usernames.txt`.

For any modifications, feel free to edit `main.py` and adjust the settings accordingly.

